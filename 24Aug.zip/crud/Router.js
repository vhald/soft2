import React, { useRef, useEffect, useState } from 'react'
import { View } from 'react-native'

import Create from './Create'
import Read from './Read'
import Edit from './Edit'
import Detail from './Detail'
import Login from './Login'

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import auth from '@react-native-firebase/auth';

const Stack = createNativeStackNavigator();



//start from here
const App = (props) => {

  const [state, setstate] = useState({ loading: true, currentUser: null })

  useEffect(()=> {

      auth().onAuthStateChanged((user) => {
        if (user) {
          var uid = user.uid;
          console.log('uid onAuthStateChanged',uid)
            setstate(prev => ({...prev, currentUser: uid, loading: false }))
        } else {
          console.log('user is signout')
            setstate(prev => ({...prev, currentUser: null, loading: false }))
        }
      });

  },[])

  const loginPage = () => {
    const currentUser = auth().currentUser
    console.log('currentUser on router page',currentUser)
    setstate(prev => ({...prev, currentUser, loading: false }))
  }

  return (

      <NavigationContainer>
      <Stack.Navigator>
            {state.currentUser === null ? (
                <Stack.Screen name="login" component={Login} />
            )
            : (
                <>
                <Stack.Screen name="home" component={Read} />
                <Stack.Screen name="detail" component={Detail} />
                <Stack.Screen name="create" component={Create} />
                <Stack.Screen name="edit" component={Edit} />
                </>
            )
            }
     </Stack.Navigator>
      </NavigationContainer>

  )

}
// ends here



export default App;
