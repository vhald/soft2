import React,  { useEffect, useState } from 'react'
import { View, Text, TouchableOpacity, Button, TextInput } from 'react-native'
import firestore from '@react-native-firebase/firestore'
import toast from 'react-native-simple-toast'

const App = ({ navigation, route }) => {

  console.log('route',route.params)

  const [state, setState] = useState({ title: route.params.title, body: route.params.body })

  useEffect(()=> {

  }, [])

  const submitForm = () => {
      console.log('triggered')

      // set , set with merge , update

      firestore().collection('news').doc(route.params.id).update({ title: state.title, body: state.body, status: true })
      .then(res => {
          console.log('res',res)
          toast.show('Item updated successfully')
          route.params.reload()
      }).catch(error => {
        console.log('err',error)
          toast.show('error to update')
      })
  }

  return (
    <View style={{ flex: 1, backgroundColor: 'white', padding: 20 }}>

    <TextInput autfocus value={state.title} onChangeText={(title)=> setState(prev => ({...prev, title }))} style={{ color: 'black', borderColor: 'grey', borderWidth: 1, borderRadius: 5, padding: 5 }} />

    <TextInput value={state.body} onChangeText={(body)=> setState(prev => ({...prev, body }))} style={{ marginVertical: 20, color: 'black', borderColor: 'grey', borderWidth: 1, borderRadius: 5, padding: 5 }} />


    <Button onPress={submitForm} title="Submit"  />

    </View>
  )
}

export default App;
