import React,  { useEffect, useState } from 'react'
import { View, Text, TouchableOpacity, Button, TextInput, FlatList, Alert, ScrollView } from 'react-native'
import axios from 'axios'
import firestore from '@react-native-firebase/firestore'
import Icon from 'react-native-vector-icons/AntDesign'
import toast from 'react-native-simple-toast'

const App = ({navigation }) => {

  const [data, setState] = useState([])

  const mylistarray = () => {

    const elementArray = []

  data.forEach((item, i) => {
    console.log('item',item.title, item.body)
    elementArray.push(
      <TouchableOpacity onPress={()=>navigation.navigate('detail', { body: item.body, id: item.id })} style={{ borderBottomColor: 'black', borderBottomWidth: 1, padding: 20 }}>
          <Text style={{ color: 'black', fontSize: 20, fontWeight: 'bold' }}>{item.title} </Text>
          <Text style={{ color: 'black', fontSize: 20, fontWeight: 'bold' }}>ID {item.id} </Text>
      </TouchableOpacity>
    )
  });

    //console.log('elementArray',elementArray)
    return elementArray

  }


  useEffect(()=> {

    axios.get('https://jsonplaceholder.typicode.com/posts')
    .then(response => {
      console.log('response',response.data)
      setState(response.data)
    }).catch(error => {
        console.log('error',error)
    })


  }, [])



  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <ScrollView>
      {mylistarray()}
      </ScrollView>
    </View>
  )
}

export default App;
