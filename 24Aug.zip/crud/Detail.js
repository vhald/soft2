import React,  { useEffect, useState } from 'react'
import { View, Text, TouchableOpacity, Button, TextInput, FlatList, Alert, ScrollView } from 'react-native'
import axios from 'axios'
import toast from 'react-native-simple-toast'

const App = ({navigation, route }) => {

  console.log('route',route.params)
  const [data, setState] = useState([])
  


  useEffect(()=> {
    getComments()
  },[])

  const getComments = () => {
    axios.get(`https://jsonplaceholder.typicode.com/comments?postId=${route.params.id}`)
    .then(response => {
        console.log('comments',response.data)
          setState(response.data)
    })
  }

  const mylistarray = () => {
    const elementArray = []

      data.forEach((item, i) => {
        console.log('item',item.title, item.body)
        elementArray.push(
          <View style={{ borderBottomColor: 'black', borderBottomWidth: 1, padding: 20 }}>
              <Text style={{ color: 'black', fontWeight: 'bold', fontSize: 11 }}>{item.name} </Text>
              <Text style={{ color: 'black', fontSize: 11 }}>{item.body} </Text>
          </View>
        )
      });

      //console.log('elementArray',elementArray)
      return elementArray
  }

  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>

          <Text style={{ color: 'black', fontSize: 14, padding: 10 }}>{route.params.body}</Text>


          <View style={{ padding: 20, borderTopColor: 'black', borderTopWidth: 1 }}>

              <Text style={{ color: 'black' }}>total comments: {data.length}</Text>

              <ScrollView>
              {mylistarray()}
              </ScrollView>


          </View>

    </View>
  )
}

export default App;
