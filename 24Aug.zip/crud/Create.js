import React,  { useEffect, useState } from 'react'
import { View, Text, TouchableOpacity, Button, TextInput, Platform, Image, ActivityIndicator } from 'react-native'

import firestore from '@react-native-firebase/firestore'  //database access -firstore
import storage from '@react-native-firebase/storage'; // to access firebase storage


import ImagePicker from 'react-native-image-crop-picker'
import ActionSheet from 'react-native-action-sheet';

import toast from 'react-native-simple-toast'
const App = () => {

  const [state, setState] = useState({ title: '', body: '' })
  const [selectedImage, setSelectedImage] = useState(null)
  const [loading, setloading]= useState(false)

  useEffect(()=> {



  }, [])

  const openCamera = () => {
    ImagePicker.openCamera({
      width: 250,
      height: 250,
      compressImageQuality: 0.7,
    }).then(image => {
      console.log(image);
      setSelectedImage(image)
    }).catch(error => {
        console.log('error',error)
    })
  }

  const openGallery = () => {
    ImagePicker.openPicker({
      width: 250,
      height: 250,
      compressImageQuality: 0.7,
    }).then(image => {
      console.log(image);
      setSelectedImage(image)
    }).catch(error => {
        console.log('error',error)
    })
  }

  const submitForm = async () => {

      if(String(state.title).length < 3){
        toast.show('title with min 4 characters.. ')
        return
      }

      setloading(true)
      // console.log('triggered')
      var imageName = ''

      try {
        var res = await firestore().collection('news').add({ title: state.title, body: state.body, status: true })
        if(res){
          //res.id
          //console.log('selectedImage.path',selectedImage.path)
          if(selectedImage?.path) {
          var extension = ''
          if(selectedImage.mime === 'image/jpeg'){
            extension = 'jpg'
          }
          else if(selectedImage.mime === 'image/png'){
              extension = 'png'
          }
          imageName = `${res.id}.${extension}`  ///
          await storage().ref(imageName).putFile(selectedImage.path)
          var url = await storage().ref(imageName).getDownloadURL()
          await firestore().collection('news').doc(res.id).update({ image: url })
          setloading(false)
          toast.show('Uploaded successfully')
          }
          else {
            setloading(false)
            toast.show('Uploaded successfully')
          }

        }
      } catch (error){
        console.log('error',error)
      }




  }

  const openActionSheet = () => {

    var BUTTONSiOS = [
      'Camera',
      'CameraRoll',
      'Cancel'
    ];

    var BUTTONSandroid = [
      'Camera',
      'ImageGallery',
      'Cancel'
    ];

    var CANCEL_INDEX = 2;

    ActionSheet.showActionSheetWithOptions({
      options: (Platform.OS == 'ios') ? BUTTONSiOS : BUTTONSandroid,
      cancelButtonIndex: CANCEL_INDEX,
      tintColor: 'blue'
    },
    (buttonIndex) => {
      console.log('button clicked :', buttonIndex);
      if(buttonIndex === 0){
        openCamera()
      } else if (buttonIndex === 1){
          openGallery()
      }

    });

  }

  return (
    <View style={{ flex: 1, backgroundColor: 'white', padding: 20 }}>

      {loading && (
        <ActivityIndicator animating size={'large'} />
      )}

      <Text style={{ color: 'black' }}>Title*</Text>
    <TextInput autfocus value={state.title} onChangeText={(title)=> setState(prev => ({...prev, title }))} style={{ color: 'black', borderColor: 'grey', borderWidth: 1, borderRadius: 5, padding: 5 }} />

      <Text style={{ color: 'black' }}>Description</Text>
    <TextInput value={state.body} onChangeText={(body)=> setState(prev => ({...prev, body }))} style={{ marginVertical: 20, color: 'black', borderColor: 'grey', borderWidth: 1, borderRadius: 5, padding: 5 }} />

    <Text style={{ color: 'black' }}>Pick An Image</Text>
    <TouchableOpacity onPress={openActionSheet} style={{ borderRadius: 15, width: 252, height: 252, borderColor: 'black', borderWidth: 1, backgroundColor: '#fafafa', padding: 2, marginBottom: 20  }}>
            {selectedImage !== null && (
              <Image source={{ uri: selectedImage.path }} style={{ width: 246, height: 246, borderRadius: 15 }} />
            )}
    </TouchableOpacity>

    <Button onPress={submitForm} title="Submit"  />

    </View>
  )
}

export default App;
