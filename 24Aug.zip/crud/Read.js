import React,  { useEffect, useState } from 'react'
import { View, Text, TouchableOpacity, Button, TextInput, FlatList, Alert } from 'react-native'
import firestore from '@react-native-firebase/firestore'
import Icon from 'react-native-vector-icons/AntDesign'
import toast from 'react-native-simple-toast'
import AsyncStorage from '@react-native-async-storage/async-storage';
import auth from '@react-native-firebase/auth';
const App = ({navigation }) => {

  const [data, setState] = useState([])
  const [visited, setVisited] = useState([])



  // sfdfsdf: true


  useEffect(()=> {

    getVisitedData()

    getData()

  }, [])

  // this method executes only when we open our application ....
  const getVisitedData = async () => {
    try {
      let jsonValue = await AsyncStorage.getItem('@visitedNews')
      console.log('jsonValue',jsonValue)
      if(jsonValue !== null){
        jsonValue = JSON.parse(jsonValue)
        setVisited(jsonValue)
      }

    } catch(e) {
      // error reading value
      console.log('error',e)
    }
  }

  const getData = () => {
    var rowData = []
    firestore().collection('news').get()
    .then(snapShot => {
        snapShot.docs.map(eachDoc => {
            //console.log('eachDoc',eachDoc.data(), eachDoc.id )
            rowData.push({id: eachDoc.id, ...eachDoc.data() })
        })
        setState(rowData)
    }).catch(error => {
        console.log('errr',error)
    })
  }

  useEffect(()=> {
    console.log('visited current is > ',visited)
  },[visited])




  const visitDetail = async (id,body) => {
    var tempVisited = visited; //[1]
    if(tempVisited.indexOf(id) == -1){
      tempVisited.push(id) // [1,2]
    }
    setVisited([...tempVisited])

    try {
      var converttoString = JSON.stringify(tempVisited)
      await AsyncStorage.setItem('@visitedNews',converttoString)
      console.log('we updated the storage too..')
      }
     catch(e) {
      console.log('error to save data',e)
    }


    navigation.navigate('detail', { id: id, body: body })
  }


  const renderItem = ({item, index }) => {
    //console.log('item>>',item)
    return (
      <View style={{ borderBottomWidth: 1, borderBottomColor: 'grey', paddingVertical: 10, flexDirection: 'row', backgroundColor: visited.indexOf(item.id) !== -1 ? '#bfbfbf': '#fff' }}>
          <TouchableOpacity onPress={()=> visitDetail(item.id, item.body)} style={{ flex: 5 }}>
          <Text style={{ color: 'black', fontSize: 16, foneWeight: '400' }}>{item.title}</Text>
          <Text style={{ color: 'black'}}>{item.body}</Text>
          </TouchableOpacity>

          <View style={{ flex: 1.5, flexDirection: 'row' }}>
          <TouchableOpacity onPress={()=>navigation.navigate('edit', { id: item.id, title: item.title, body: item.body, reload: getData } )} style={{  justifyContent: 'center' }}>
            <Icon name="edit" size={18} color={'black'} />
          </TouchableOpacity>
          <TouchableOpacity onPress={()=>deleteDocument(item.id)} style={{  marginLeft: 20, justifyContent: 'center' }}>
            <Icon name="delete" size={18} color={'red'} />
          </TouchableOpacity>
          </View>
      </View>
    )
  }


  // const preDelete = (id) => {
  //   Alert.alert(
  //     "Alert",
  //     "Are you sure want to delete this record ?",
  //     [
  //       {
  //         text: "Cancel",
  //         onPress: () => console.log("Cancel Pressed"),
  //         style: "cancel"
  //       },
  //       { text: "Yes, do it!", onPress: () => deleteDocument(id) }
  //     ]
  //   );
  // }

  const deleteDocument = (id) => {
    firestore().collection('news').doc(id).delete()
    .then(()=> {
          toast.show('Item deleted successfully')
          getData()
    }).catch(error => {
        console.log('error')
        toast.show('Error to delete')
    })
  }

  return (
    <View style={{ flex: 1, backgroundColor: 'white', padding: 20 }}>

        <FlatList
         data={data}
         renderItem={renderItem}
         keyExtractor={item => item.id}
       />

       <TouchableOpacity onPress={()=>navigation.navigate('create')} style={{ justifyContent: 'center', alignItems: 'center', position: 'absolute', bottom: 20, right: 20 , borderRadius: 30, width: 60, height: 60, backgroundColor: 'blue' }} >
            <Icon name={'plus'} color={'white'} />
       </TouchableOpacity>


       <TouchableOpacity onPress={()=>auth().signOut()} style={{ justifyContent: 'center', alignItems: 'center', position: 'absolute', top: 5, right: 10 , width: 50, height: 50,  backgroundColor: 'blue' }} >
            <Icon name={'user'} color={'white'} />
       </TouchableOpacity>

    </View>
  )
}

export default App;
